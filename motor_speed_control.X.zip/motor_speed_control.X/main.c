#include "Timer.h"
#include "interrupt.h"
#include "GPIO.h"
#include <avr/io.h>
#include <avr/interrupt.h>

#define PPR  10 
#define F_CPU 16000000UL

volatile uint16_t encoder_counts = 0;
volatile uint16_t rpm = 0;

ISR(TIMER1_COMPA_vect) {
    rpm = (encoder_counts * 60) / PPR;
    encoder_counts = 0; 
}
ISR(INT0_vect) {
    encoder_counts++;
}


void main(void) {
    return;
}
