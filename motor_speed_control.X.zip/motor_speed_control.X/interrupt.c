#include "interrupt.h"

void EXT_INT_Init() {
    cli(); // Disable global interrupts
    // INT0 trigger on the falling edge of encoder pulse (pullup resistor)
    EICRA = (1 << ISC01) | (0 << ISC00);
    // Enable INT0 
    EIMSK = (1 << INT0);
    sei(); // Enable global interrupts
}
