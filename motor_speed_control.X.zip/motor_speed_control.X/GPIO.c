#include "GPIO.h"

void GPIO_Init(void) {
    
    DDRD |= (1 << PD6); // Configure PD6 (OC0A) as output for PWM
    DDRD &= ~(1 << PD2); // Clear PD2 (INT0) to make it an input
    PORTD |= (1 << PD2); // Enable pull-up resistor on PD2
}
