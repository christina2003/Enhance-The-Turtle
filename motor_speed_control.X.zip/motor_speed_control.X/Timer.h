#ifndef TIMER_H
#define TIMER_H

#include <avr/io.h>

void Timer0_Init(void);
void Timer1_Init(void);

#endif 
