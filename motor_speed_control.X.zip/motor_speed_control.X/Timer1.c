
#include <xc.h>
#include <avr/io.h>
#include"Timer0.h"
#include <avr/interrupt.h>
  

void TIMER0_Init() {
    // Set Timer0 to Fast PWM mode with TOP at 0xFF
    TCCR0A = (1 << WGM01) | (1 << WGM00) | (1 << COM0A1);  // Fast PWM mode, Non-inverting mode
    TCNT0=0;
    TCCR0B = (1 << CS01) | (1 << CS00);  // Prescaler = 64
    OCR0A = duty_cycle;
}

void Timer1_Init(){
    //set timer1 to CTC mode (Clear timer on compare match)
    TCCR1B |= (1<< WGM12); // CTC mode
    // calculate OCR1A value to make interrupt every 1 sec
    //OCR1A = ((f_CPU / prescaler *desired freq))-1
    //prescaler = 1024 , desired freq = 1Hz , f_CPU = 16MHz
    OCR1A=15624;
    // Enable Timer1 Compare Match A interrupt , The corresponding interrupt vector is executed when the OCF1A flag, located in TIFR1, is set.
    TIMSK1 |= (1 << OCIE1A);
    //set prescaler to 1024 and start timer 1
    TCCR1B |= (1<<CS12) | (1<<CS10);
}

