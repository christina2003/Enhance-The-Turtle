#include "adc.h"  // Include the corresponding header file

// Initialize the ADC
void ADC_Init(void) {
    // Set ADC0 (PC0) as input
    GPIO_SetPinAsInput('C', 0);

    // Disable digital input on ADC0
    GPIO_DisableDigitalInput(0);

    // Set the reference voltage to AVcc
    ADMUX |= (1 << REFS0);

    // Set the ADC clock prescaler to 128
    ADCSRA |= (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0);

    // Enable the ADC
    ADCSRA |= (1 << ADEN);
}

// Read a value from the specified ADC channel
uint16_t ADC_Read(uint8_t channel) {
    
    // Select the corresponding channel 0~7
    ADMUX = (ADMUX & 0xF8) | (channel & 0x07);

    // Start the conversion
    ADCSRA |= (1 << ADSC);

    // Wait for the conversion to complete
    while (ADCSRA & (1 << ADSC));

    // Return the ADC result
    return ADC;
}

// Set a GPIO pin as an input
void GPIO_SetPinAsInput(uint8_t port, uint8_t pin) {
    switch(port) {
        case 'B':
            DDRB &= ~(1 << pin); // Set PBx as input
            break;
        case 'C':
            DDRC &= ~(1 << pin); // Set PCx as input
            break;
        case 'D':
            DDRD &= ~(1 << pin); // Set PDx as input
            break;
    }
}

// Disable digital input on a specific ADC channel
void GPIO_DisableDigitalInput(uint8_t adc_channel) {
    switch(adc_channel) {
        case 0:
            DIDR0 |= (1 << ADC0D); // Disable digital input on ADC0
            break;
        // add more cases if needed
    }
}
