#include "adc.h"  // Include the ADC header file

int main(void) {
    // Initialize the ADC
    ADC_Init();

    // Main loop
    while (1) {
        // Read a value from ADC channel 0 (from a potentiometer)
        uint16_t adc_value = ADC_Read(0);
        
    }
    return 0;
}

