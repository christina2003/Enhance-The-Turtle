#ifndef ADC_H
#define ADC_H

#include <xc.h> // include processor files - each processor file is guarded.
#include <avr/io.h>  // Include AVR IO library for register definitions

// Function prototypes
void ADC_Init(void);
uint16_t ADC_Read(uint8_t channel);

// GPIO-related prototypes
void GPIO_SetPinAsInput(uint8_t port, uint8_t pin);
void GPIO_DisableDigitalInput(uint8_t adc_channel);

#endif /* ADC_H */

  

